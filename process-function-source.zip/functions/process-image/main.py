import json, os
from google.cloud import storage, pubsub_v1
from PIL import Image
import io

def process_image(event, context):
    data = json.loads(event['data'])
    bucket_name = data["bucket"]
    name = data["name"]

    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(name)
    img_bytes = blob.download_as_bytes()

    img = Image.open(io.BytesIO(img_bytes)).convert("L")

    out_bucket = client.bucket(os.environ["PROCESSED_BUCKET"])
    out_blob = out_bucket.blob(name)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    out_blob.upload_from_string(buf.getvalue())

    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(os.environ["GCP_PROJECT"], os.environ["RESULT_TOPIC"])
    publisher.publish(topic_path, json.dumps({"file": name}).encode())

